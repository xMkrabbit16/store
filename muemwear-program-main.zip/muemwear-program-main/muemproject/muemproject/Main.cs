﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace muemproject
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void kullanici_Click(object sender, EventArgs e)
        {
            users gecis = new users();
            gecis.Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AddItem gecis3 = new AddItem();
            gecis3.Show();
            this.Hide();
        }
    }
}
